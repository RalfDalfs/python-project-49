import prompt

SCORE = 3


def launch(game):
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    print(game.DESCRIPTION)
    index = 0

    while index<SCORE:
        question, correct_answer=game.get_round_data()
        print(f'Question: {question}')
        answer=prompt.string('Your answer:')

        if answer.lower()==current_answer:
            print('Current')
        else:
            print(f"'{answer}' is wrong answer ;(. "
                  f"Correct answer was '{correct_answer}'.")
            print(f'Let\'s try again, {name}!')
            return
        index = index + 1
    print(f'Congratulations {name}')